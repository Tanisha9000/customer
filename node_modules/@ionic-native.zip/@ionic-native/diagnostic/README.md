<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/diagnostic/index.ts#L1">
  Improve this doc
</a>

# Diagnostic

```
$ ionic cordova plugin add cordova.plugins.diagnostic
$ npm install --save @ionic-native/diagnostic
```

## [Usage Documentation](https://ionicframework.com/docs/native/diagnostic/)

Plugin Repo: [https://github.com/dpa99c/cordova-diagnostic-plugin](https://github.com/dpa99c/cordova-diagnostic-plugin)

Checks whether device hardware features are enabled or available to the app, e.g. camera, GPS, wifi

## Supported platforms
- Android
- iOS
- Windows



