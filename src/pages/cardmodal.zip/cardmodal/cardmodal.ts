import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Stripe } from '@ionic-native/stripe';
import { PurchasePage } from '../purchase/purchase';
import { ViewController, ToastController } from 'ionic-angular';

import { CustomerProvider } from '../../providers/customer/customer';
import { Http, RequestOptions,Headers } from '@angular/http';
@IonicPage()
@Component({
  selector: 'page-cardmodal',
  templateUrl: 'cardmodal.html',
})
export class CardmodalPage {

public card;
public cards={
  number: '',
 expYear: 0,
 expMonth: 0,
  cvc: ''
}
 monthes=[];

  constructor(public navCtrl: NavController, 
    public navParams: NavParams,
    public stripe: Stripe,
    public viewCtrl: ViewController,
    public toastCtrl: ToastController,
    public http: Http,
    public customer: CustomerProvider,) {
 this.monthe();
  }
  public monthe(){
for(let i=1; i<=12; i++){
  if(i<10){
this.monthes.push("0"+i);
  }else{
    this.monthes.push(JSON.stringify(i));
  }
}
console.log(this.monthes);  
  }

  public serializeObj(obj) {
    var result = [];
    for (var property in obj)
      result.push(encodeURIComponent(property) + "=" + encodeURIComponent(obj[property]));
    return result.join("&");
  }

updatedata(carddata)
{
console.log(carddata.value)
console.log(this.cards.expMonth)
 this.card = {
  number: this.cards.number,
  expMonth : this.cards.expMonth,
  expYear: this.cards.expYear,
  cvc: this.cards.cvc
 };

this.stripe.setPublishableKey('pk_test_Ldj5kbIUV3FXI5cfoYZw9qfY');
   //alert(JSON.stringify(card));
this.stripe.createCardToken(this.card).then((token=>{
var postdata={
user_id : localStorage.getItem('user_id'),
getit : 'save_card',
token : token.id
  }
            console.log(postdata)
            var serialized_all = this.serializeObj(postdata);
            let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8' });
            let options = new RequestOptions({ headers : headers });
            this.http.post(this.customer.base_url + 'ticket.php', serialized_all, options)
            .map(res=>res.json())
           .subscribe((dataa)=>{ 
            console.log(dataa)
                     
            var toast = this.toastCtrl.create({
               message: "The details of card are saved",
              duration: 5000,
               position: 'bottom'
               });
               toast.present();
               this.card={
                number:'',
                expMonth :'',
                expYear:'',
                cvc: '' 

               };
               this.viewCtrl.dismiss();
              })

       })).catch((error=>{
        var toast = this.toastCtrl.create({
          message: JSON.stringify(error),
         duration: 5000,
          position: 'bottom'
          });
          toast.present();
       }))



}

  closeModal() {
   
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad CardmodalPage');
  }

}
