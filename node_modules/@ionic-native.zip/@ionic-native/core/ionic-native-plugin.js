var IonicNativePlugin = (function () {
    function IonicNativePlugin() {
    }
    /**
     * Returns a boolean that indicates whether the plugin is installed
     * @return {boolean}
     */
    IonicNativePlugin.installed = function () { return false; };
    /**
     * Returns the original plugin object
     */
    IonicNativePlugin.getPlugin = function () { };
    /**
     * Returns the plugin's name
     */
    IonicNativePlugin.getPluginName = function () { return; };
    /**
     * Returns the plugin's reference
     */
    IonicNativePlugin.getPluginRef = function () { return; };
    /**
     * Returns the plugin's install name
     */
    IonicNativePlugin.getPluginInstallName = function () { return; };
    /**
     * Returns the plugin's supported platforms
     */
    IonicNativePlugin.getSupportedPlatforms = function () { return; };
    return IonicNativePlugin;
}());
export { IonicNativePlugin };
//# sourceMappingURL=ionic-native-plugin.js.map