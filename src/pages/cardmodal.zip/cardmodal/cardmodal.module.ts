import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CardmodalPage } from './cardmodal';

@NgModule({
  declarations: [
    CardmodalPage,
  ],
  imports: [
    IonicPageModule.forChild(CardmodalPage),
  ],
})
export class CardmodalPageModule {}
