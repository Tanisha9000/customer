<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/barcode-scanner/index.ts#L61">
  Improve this doc
</a>

# Barcode Scanner

```
$ ionic cordova plugin add phonegap-plugin-barcodescanner
$ npm install --save @ionic-native/barcode-scanner
```

## [Usage Documentation](https://ionicframework.com/docs/native/barcode-scanner/)

Plugin Repo: [https://github.com/phonegap/phonegap-plugin-barcodescanner](https://github.com/phonegap/phonegap-plugin-barcodescanner)

The Barcode Scanner Plugin opens a camera view and automatically scans a barcode, returning the data back to you.

Requires Cordova plugin: `phonegap-plugin-barcodescanner`. For more info, please see the [BarcodeScanner plugin docs](https://github.com/phonegap/phonegap-plugin-barcodescanner).

## Supported platforms
- Android
- BlackBerry 10
- Browser
- iOS
- Windows



